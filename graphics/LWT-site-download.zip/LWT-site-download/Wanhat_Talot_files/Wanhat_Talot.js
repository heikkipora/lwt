// Created by iWeb 3.0.2 local-build-20110126

function createMediaStream_id11()
{return IWCreatePhotocast("file://localhost/Users/minervaoconnor/Desktop/Julkaistut/LoviisanWanhatTalot/Wanhat_Talot_files/rss.xml",true);}
function initializeMediaStream_id11()
{createMediaStream_id11().load('file://localhost/Users/minervaoconnor/Desktop/Julkaistut/LoviisanWanhatTalot',function(imageStream)
{var entryCount=imageStream.length;var headerView=widgets['widget1'];headerView.setPreferenceForKey(imageStream.length,'entryCount');NotificationCenter.postNotification(new IWNotification('SetPage','id11',{pageIndex:0}));});}
function layoutMediaGrid_id11(range)
{createMediaStream_id11().load('file://localhost/Users/minervaoconnor/Desktop/Julkaistut/LoviisanWanhatTalot',function(imageStream)
{if(range==null)
{range=new IWRange(0,imageStream.length);}
IWLayoutPhotoGrid('id11',new IWPhotoGridLayout(2,new IWSize(309,309),new IWSize(309,48),new IWSize(309,372),27,27,0,new IWSize(0,0)),new IWEmptyStroke(),imageStream,range,new IWShadow({blurRadius:10,offset:new IWPoint(4.2426,4.2426),color:'#000000',opacity:0.750000}),null,1.000000,null,'Media/slideshow.html','widget1','widget2','widget3')});}
function relayoutMediaGrid_id11(notification)
{var userInfo=notification.userInfo();var range=userInfo['range'];layoutMediaGrid_id11(range);}
function onStubPage()
{var args=window.location.href.toQueryParams();parent.IWMediaStreamPhotoPageSetMediaStream(createMediaStream_id11(),args.id);}
if(window.stubPage)
{onStubPage();}
setTransparentGifURL('Media/transparent.gif');function hostedOnDM()
{return false;}
function onPageLoad()
{IWRegisterNamedImage('comment overlay','Media/Photo-Overlay-Comment.png')
IWRegisterNamedImage('movie overlay','Media/Photo-Overlay-Movie.png')
loadMozillaCSS('Wanhat_Talot_files/Wanhat_TalotMoz.css')
adjustLineHeightIfTooBig('id1');adjustFontSizeIfTooBig('id1');adjustLineHeightIfTooBig('id2');adjustFontSizeIfTooBig('id2');adjustLineHeightIfTooBig('id3');adjustFontSizeIfTooBig('id3');adjustLineHeightIfTooBig('id4');adjustFontSizeIfTooBig('id4');adjustLineHeightIfTooBig('id5');adjustFontSizeIfTooBig('id5');adjustLineHeightIfTooBig('id6');adjustFontSizeIfTooBig('id6');adjustLineHeightIfTooBig('id7');adjustFontSizeIfTooBig('id7');adjustLineHeightIfTooBig('id8');adjustFontSizeIfTooBig('id8');adjustLineHeightIfTooBig('id9');adjustFontSizeIfTooBig('id9');adjustLineHeightIfTooBig('id10');adjustFontSizeIfTooBig('id10');NotificationCenter.addObserver(null,relayoutMediaGrid_id11,'RangeChanged','id11')
adjustLineHeightIfTooBig('id13');adjustFontSizeIfTooBig('id13');adjustLineHeightIfTooBig('id14');adjustFontSizeIfTooBig('id14');Widget.onload();fixAllIEPNGs('Media/transparent.gif');fixupIECSS3Opacity('id12');initializeMediaStream_id11()
performPostEffectsFixups()}
function onPageUnload()
{Widget.onunload();}
